function load() {
    fetch('/addToSession');
}